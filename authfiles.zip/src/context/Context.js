import React, {createContext, useEffect, useState, navigate} from 'react'
import {myAxios} from "../service/axios"

 export const MyContext = createContext();
 
 export default function Context({children}) {
   const [auth, setAuth] = useState ({
      user: null,
      token: null,
      isAuth: false,
      loading: false,   
    })

    useEffect(() => {
      if(!localStorage.getItem("Token")) return;
      userme()
    },[])

    async function userme() {
      setAuth((p) => ({
        ...p,
        loading: true,
      }));
      try {
        const res = await myAxios("/auth/userme")
        setAuth((p) => ({
          ...p,
          user: res.data.user,
          token: localStorage.getItem("Token"),
          isAuth: true,
        }))
      } catch (error) {
        localStorage.removeItem("Token"),
        navigate("/login")
      }finally{
        setAuth((p) => ({
          ...p,
          loading: false,
        }))
      }

    }

   async function register(body) {
      setAuth((p) => ({
        ...p,
        loading: true,
      }));
      try {
        const res = await myAxios.post("/auth/register",body)
        setAuth((p) => ({
          ...p,
          user: res.data.user,
          token: res.data.token,
          isAuth: true,
        }));
      } catch (error) {
        console.error(error)
      } finally{
        setAuth((p) => ({
          ...p,
          loading: false
        }))
      }
    }

    async function login(body) {
      setAuth((p) => ({
        ...p,
        loading: true,
      }));
      try {
        const res = await myAxios.post("/auth/login", body);
        setAuth((p) => ({
          ...p,
          user: res.data.user,
          token: res.data.token,
          isAuth: true,
        }))
        localStorage.setItem("Token", res.data.token)
      } catch (error) {
        
      }finally{
        setAuth((p) => ({
          ...p,
          loading: false,
        }))
      }
    }

  return (
    <MyContext.Provider value={{
          state: {
           auth,
          },
          fn: {
           register,
           login,
          },
    }}
    >{children}</MyContext.Provider>
  )
}
