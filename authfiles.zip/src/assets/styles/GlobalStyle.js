import { createGlobalStyle } from "styled-components";

//
import './Fonts.css'


const GlobalStyles = createGlobalStyle`
     *{
          margin: 0;
          padding: 0;
          box-sizing: border-box;
          font-family: 'Roboto', sans-serif;
     
     }
     .container {
          max-width: 1200px;
          margin: 27px auto;

     }
     .f-center {
          display: flex;
          align-items: center;
          justify-content: center;
     }
`

export default GlobalStyles