import React from 'react'
import { BrowserRouter } from 'react-router-dom'
import GlobalStyles from './assets/styles/GlobalStyle'
import Context from './context/Context'
import Routee from './Route/Route'

export default function App() {
  return (
    <BrowserRouter>
      <Context>
      <GlobalStyles/>
      <Routee/>
      </Context>
    </BrowserRouter>
  )
}
