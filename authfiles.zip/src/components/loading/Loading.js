import React from 'react'
import styled from 'styled-components'
import { Watch } from  'react-loader-spinner'


export default function Loading() {
  return (
    <StyledLoading>
          <main>
            <Watch 
              height = "80"
              width = "80"
              radius = "9"
              color = 'green'
            />
          </main>
    </StyledLoading>
  )
}
const StyledLoading = styled.div`
   min-height: 100vh;
   background-color: #fff;
   display: flex;
   align-items: center;
   justify-content: center;
`