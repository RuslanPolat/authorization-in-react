import React, { useState } from 'react'

export default function Main() {

  const [count, setCount] = useState(0)
  return (
    <div>
      <h1>Count</h1>
      <div>
        <h2>{count}</h2>
        <button onClick={() => setCount(count + 1)}>dec</button>
        <button onClick={() => setCount(count - 1)}>inc</button>
        <button onClick={() => setCount(0)}>reset</button>
      </div>
    </div>
  )
}
