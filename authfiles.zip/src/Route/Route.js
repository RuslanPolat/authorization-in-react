import React, {useContext} from 'react'
import { Routes, Route, Navigate, Outlet } from 'react-router-dom'

// pages
import ToDo from '../components/todo/ToDo';
import Register from '../Pages/register/Register';
import Login from '../Pages/login/Login';
import { MyContext } from "../context/Context"
import Loading from '../components/loading/Loading';

export default function Routee() {

  const { state: {
    auth: {loading, isAuth},
    },
  } = useContext(MyContext)

  if(loading) return <Loading/>

  if(isAuth) 
  return (
  <Routes>
    <Route path='/todo' element={<ToDo/>}/>
    <Route path='*' element={<Navigate to='todo'/>}/>
  </Routes>
  )

  return (
    <div>
     <Routes>
          <Route path='register' element={<Register/>}/>
          <Route path='login' element={<Login/>}/>
          <Route path='*' element={<Navigate to='login'/>}/>
     </Routes>
    </div>
  )
}
